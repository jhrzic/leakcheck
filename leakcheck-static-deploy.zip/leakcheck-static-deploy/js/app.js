const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("file-input");
const browseBtn = document.getElementById("browse-btn");
const uploadError = document.getElementById("upload-error");

const dropzoneSection = document.getElementById("dropzone-section");
const loadingSection = document.getElementById("loading");
const resultsSection = document.getElementById("results");

const fieldsList = document.getElementById("fields-list");
const noLeaksMsg = document.getElementById("no-leaks-msg");
const fieldCountBadge = document.getElementById("field-count-badge");
const resultFilename = document.getElementById("result-filename");

const gradeLetter = document.getElementById("grade-letter");
const gradeStamp = document.getElementById("grade-stamp");
const scoreNumber = document.getElementById("score-number");
const scoreLabel = document.getElementById("score-label");

const downloadClean = document.getElementById("download-clean");
const resetBtn = document.getElementById("reset-btn");

const shareX = document.getElementById("share-x");
const shareFarcaster = document.getElementById("share-farcaster");

let lastObjectUrl = null;

browseBtn.addEventListener("click", () => fileInput.click());
dropzone.addEventListener("click", () => fileInput.click());

["dragenter", "dragover"].forEach((evt) => {
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.add("border-tag-amber");
  });
});

["dragleave", "drop"].forEach((evt) => {
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.remove("border-tag-amber");
  });
});

dropzone.addEventListener("drop", (e) => {
  const file = e.dataTransfer.files[0];
  if (file) handleFile(file);
});

fileInput.addEventListener("change", () => {
  const file = fileInput.files[0];
  if (file) handleFile(file);
});

resetBtn.addEventListener("click", () => {
  resultsSection.classList.add("hidden");
  dropzoneSection.classList.remove("hidden");
  fileInput.value = "";
  uploadError.classList.add("hidden");
  if (lastObjectUrl) {
    URL.revokeObjectURL(lastObjectUrl);
    lastObjectUrl = null;
  }
});

function showError(msg) {
  uploadError.textContent = msg;
  uploadError.classList.remove("hidden");
}

async function handleFile(file) {
  uploadError.classList.add("hidden");

  const allowed = ["image/jpeg", "image/png", "image/webp", "image/tiff", "image/heic", "image/heif"];
  if (!allowed.includes(file.type)) {
    showError("Unsupported file type. Try a JPEG, PNG, WEBP, TIFF, or HEIC.");
    return;
  }
  if (file.size > 10 * 1024 * 1024) {
    showError("File too large. 10MB max on this deployment.");
    return;
  }

  dropzoneSection.classList.add("hidden");
  loadingSection.classList.remove("hidden");
  resultsSection.classList.add("hidden");

  const formData = new FormData();
  formData.append("file", file);

  try {
    const res = await fetch("/api/upload", { method: "POST", body: formData });

    if (res.status === 404) {
      throw new Error("The audit engine isn't connected on this deploy yet — this is the static preview only.");
    }

    const data = await res.json();

    if (!data.ok) {
      throw new Error(data.error || "Audit failed.");
    }

    renderResults(data);
  } catch (err) {
    loadingSection.classList.add("hidden");
    dropzoneSection.classList.remove("hidden");
    showError(err.message || "Something went wrong reading that file.");
  }
}

function base64ToBlob(base64, mime) {
  const byteChars = atob(base64);
  const byteNumbers = new Array(byteChars.length);
  for (let i = 0; i < byteChars.length; i++) {
    byteNumbers[i] = byteChars.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  return new Blob([byteArray], { type: mime });
}

function renderResults(data) {
  loadingSection.classList.add("hidden");
  resultsSection.classList.remove("hidden");

  resultFilename.textContent = data.filename;
  fieldCountBadge.textContent = `${data.report.fieldCount} field${data.report.fieldCount === 1 ? "" : "s"} found`;

  fieldsList.innerHTML = "";

  if (data.report.findings.length === 0) {
    noLeaksMsg.classList.remove("hidden");
  } else {
    noLeaksMsg.classList.add("hidden");
    data.report.findings.forEach((finding, i) => {
      const row = document.createElement("div");
      row.className = "field-row";
      row.style.opacity = "0";
      row.style.animation = `fadeIn 0.3s ease forwards ${i * 0.08}s`;
      row.innerHTML = `
        <span class="field-key">${finding.label}</span>
        <span class="field-val leaking">${escapeHtml(String(finding.value))}</span>
      `;
      fieldsList.appendChild(row);
    });
  }

  gradeLetter.textContent = data.report.grade;
  scoreNumber.textContent = `${data.report.score}/100`;
  scoreLabel.textContent = data.report.gradeLabel;

  if (data.report.score >= 70) {
    gradeStamp.classList.add("clean");
  } else {
    gradeStamp.classList.remove("clean");
  }

  if (lastObjectUrl) URL.revokeObjectURL(lastObjectUrl);
  const blob = base64ToBlob(data.cleanFileBase64, data.cleanFileMime);
  lastObjectUrl = URL.createObjectURL(blob);

  downloadClean.href = lastObjectUrl;
  downloadClean.setAttribute("download", data.filename.replace(/(\.[a-z]+)$/i, "-clean$1"));

  shareX.onclick = () => {
    const text = `I just ran LeakCheck on a photo and scored ${data.report.score}/100 (${data.report.grade}) — it found ${data.report.fieldCount} hidden field${data.report.fieldCount === 1 ? "" : "s"} I didn't know I was sharing. Check yours:`;
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(window.location.origin)}`;
    window.open(url, "_blank", "noopener");
  };

  shareFarcaster.onclick = () => {
    const text = `Ran LeakCheck on a photo. Score: ${data.report.score}/100 (${data.report.grade}). It found ${data.report.fieldCount} hidden metadata field${data.report.fieldCount === 1 ? "" : "s"}. Check what your files are leaking:`;
    const url = `https://warpcast.com/~/compose?text=${encodeURIComponent(text)}&embeds[]=${encodeURIComponent(window.location.origin)}`;
    window.open(url, "_blank", "noopener");
  };
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

const styleTag = document.createElement("style");
styleTag.textContent = `@keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }`;
document.head.appendChild(styleTag);
